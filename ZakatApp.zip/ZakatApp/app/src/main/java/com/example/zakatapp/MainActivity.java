package com.example.zakatapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.BreakIterator;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {


    EditText etGram;
    EditText etValue;
    Button CONVERT;
    TextView TvOutput;
    TextView TvOutput2;
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner aSpinner = findViewById(R.id.aSpinner);
        aSpinner.setOnClickListener(this);

        spinner = (Spinner) findViewById(R.id.aSpinner);
        adapter = ArrayAdapter.createFromResource(this, R.array.status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        etGram = (EditText) findViewById(R.id.Gram);
        etValue = (EditText) findViewById(R.id.Value);
        CONVERT = (Button) findViewById(R.id.CONVERT);
        TvOutput = (TextView) findViewById(R.id.TvOutput);
        TvOutput2 = (TextView) findViewById(R.id.TvOutput2);

        float gram;
        float value;
        CONVERT.setOnClickListener(this);
        spinner.setOnItemSelectedListener(this);



        BreakIterator addGram = null;
        addGram.setText("" + etGram);
        BreakIterator addValue = null;
        addValue.setText("" + etValue);

    }
            @Override
            public void onClick(View v) {

                try {
                    switch (v.getId()) {

                        case R.id.CONVERT:
                            CONVERT();
                            break;

                    }
                } catch (java.lang.NumberFormatException nfe) {
                    Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();

                } catch (Exception exp) {
                    Toast.makeText(this,"Unknown Exception" + exp.getMessage(), Toast.LENGTH_SHORT).show();

                    Log.d("Exception",exp.getMessage());

                }
            }

    public void CONVERT(){
        DecimalFormat df = new DecimalFormat("##.00");
        float weight = Float.parseFloat(etGram.getText().toString());
        float value = Float.parseFloat(etValue.getText().toString());
        String stat = spinner.getSelectedItem().toString();
        double totValue;
        double uruf;
        double payable;
        double totZakat;



        if (stat.equals("Keep")){
            totValue= weight * value;
            uruf= weight - 85;

            if(uruf>=0.0) {
                payable = uruf * value;
                totZakat = payable * 0.025;
            }

            else{
                payable = 0.0;
                totZakat = payable * 0.025;

            }

            TvOutput.setText("Zakat payable: RM"+ df.format(payable));
            TvOutput2.setText("Total zakat: RM"+ df.format(totZakat));
        }

        else{
            totValue= weight * value;
            uruf= weight - 200;

            if(uruf>=0.0) {
                payable = uruf * value;
                totZakat = payable * 0.025;
            }

            else{
                payable = 0.0;
                totZakat = payable * 0.025;

            }

            TvOutput.setText("Zakat payable: RM"+ df.format(payable));
            TvOutput2.setText("Total Zakat: RM"+ df.format(totZakat));

        }

    }



    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}



